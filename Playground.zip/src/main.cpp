#include <Arduino.h>
#include "servos.h"

// ============================================
// Includes - Auto-generated from blocks
// ============================================
#include "ky023.h"

#include "dcmotor.h"

#include "servos.h"


// ============================================
// Arduino Entry Points
// ============================================

void setup()
{
  // Initialize hardware and peripherals
  initializeServo(SERVO1, SERVO1_PIN);
  initializeServo(SERVO2, SERVO2_PIN);
  initializeServo(SERVO3, SERVO3_PIN);
  initDCMotors(15);  // Initialize DC motors: M1, M2, M3, M4
  initKY023(1, 1, 1);  // Initialize joystick (X:1, Y:1, Button:1)
  int myVar;
}

void loop()
{
  // Main program loop
  if (readKY023Y()  // Read joystick Y-axis (0-4095) > 0) {
      setDCSpeed(1, FORWARD, 100);  // Set motor 1 direction and speed

}
if (readKY023Y()  // Read joystick Y-axis (0-4095) <= 0) {
    setDCSpeed(1, BACKWARD, 100);  // Set motor 1 direction and speed

}
if (readKY023X()  // Read joystick X-axis (0-4095) > 0) {
    setServoAngle(SERVO1, 180);

}
if (readKY023X()  // Read joystick X-axis (0-4095) <= 0) {
    setServoAngle(SERVO1, 0);

}
}
